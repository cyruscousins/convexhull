package core;

import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class GUIHub extends JPanel{
	Main main;
	
	PointSetCollection pointSets;
	
	OptionPanel options;
	PointCanvas canvas;
	
	GUIConsole console;
	
	//Used by the options panel, set by the canvas.
	PointSet lastSelectedPointSet;
	Point lastSelectedPoint;
	
	public GUIHub(Main main, PointSetCollection pointSets){
		this.main = main;
		this.pointSets = pointSets;
		
		options = new OptionPanel(this);
		
		JPanel leftPane = new JPanel();
		leftPane.setLayout(new BoxLayout(leftPane, BoxLayout.Y_AXIS));
		
		console = new GUIConsole();
		canvas = new PointCanvas(400, 400, this);

		leftPane.add(canvas);
		leftPane.add(console);

		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		add(leftPane);
		add(options);
		
		activateGUI();
	}

	boolean guiActive; //Turn buttons and the canvas off.
	
	public void activateGUI(){ //TODO turn on listeners?
		guiActive = true;
	}
	public void deactivateGUI(){ //Turn off listeners?
		guiActive = false;
	}
	
}
